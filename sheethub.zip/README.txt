SheetHub (MVP) - README

Project name: SheetHub
Suggested public URL once deployed: https://sheethub.vercel.app

Structure:
- frontend/: Next.js app (app router). Open page at /spreadsheet
- backend/: Node.js + Express + WebSocket server.

Quick start (local):

Frontend:
1. cd frontend
2. npm install
3. npm run dev
4. Open http://localhost:3000/spreadsheet

Backend:
1. cd backend
2. npm install
3. node index.js
4. Backend on http://localhost:3001 and WS at ws://localhost:3001

Deployment (free):
- Deploy frontend to Vercel and set Environment Variable NEXT_PUBLIC_WS_URL to wss://your-backend.onrender.com
- Deploy backend to Render (or any Node host)

Notes:
- This is an MVP. For better Excel compatibility use HyperFormula.
- AG Grid community edition is used (open-source).
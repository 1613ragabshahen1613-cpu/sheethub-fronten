"use client";

import React, { useMemo, useState, useRef, useEffect } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import * as XLSX from "xlsx";

// Helpers
const colsFromNumber = (n) => {
  let s = "";
  while (n > 0) {
    const rem = (n - 1) % 26;
    s = String.fromCharCode(65 + rem) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
};

const parseCellRef = (ref) => {
  const m = ref.toUpperCase().match(/^([A-Z]+)(\d+)$/);
  if (!m) return null;
  const letters = m[1];
  let col = 0;
  for (let i = 0; i < letters.length; i++) {
    col = col * 26 + (letters.charCodeAt(i) - 64);
  }
  const row = parseInt(m[2], 10);
  return { col, row };
};

const evaluateFormula = (formula, getValue) => {
  try {
    const expr = formula.slice(1);
    const replaced = expr.replace(/([A-Za-z]+\d+)/g, (m) => {
      const r = parseCellRef(m);
      if (!r) return "0";
      const val = getValue(r.row - 1, r.col - 1);
      const num = parseFloat(String(val).replace(/,/g, ""));
      return isNaN(num) ? 0 : num;
    });
    if (!/^[0-9+\-*/(). ,]+$/.test(replaced)) return "#ERR";
    const fn = new Function("return (" + replaced + ")");
    const res = fn();
    if (typeof res === "number" && !Number.isFinite(res)) return "#NUM";
    return res;
  } catch (e) {
    return "#ERR";
  }
};

export default function SpreadsheetPage() {
  const initialRows = 20;
  const initialCols = 10;

  const [rowData, setRowData] = useState(() => {
    const rows = [];
    for (let r = 0; r < initialRows; r++) {
      const obj = {};
      for (let c = 0; c < initialCols; c++) {
        obj[colsFromNumber(c + 1)] = "";
      }
      rows.push(obj);
    }
    return rows;
  });

  const [columnDefs, setColumnDefs] = useState(() => {
    const defs = [];
    for (let c = 0; c < initialCols; c++) {
      defs.push({ field: colsFromNumber(c + 1), editable: true, resizable: true });
    }
    return defs;
  });

  const gridRef = useRef();
  const wsRef = useRef(null);
  const broadcastingRef = useRef(false);

  const getValue = (r, c) => {
    const colName = colsFromNumber(c + 1);
    if (!rowData[r]) return 0;
    return rowData[r][colName];
  };

  const computeAll = (data) => {
    const newData = data.map((row) => ({ ...row }));
    for (let r = 0; r < newData.length; r++) {
      for (let c = 0; c < Object.keys(newData[r]).length; c++) {
        const colName = colsFromNumber(c + 1);
        const v = newData[r][colName];
        if (typeof v === "string" && v.startsWith("=")) {
          const res = evaluateFormula(v, (rr, cc) => getValue(rr, cc));
          newData[r][colName] = res;
        }
      }
    }
    return newData;
  };

  const onCellValueChanged = (params) => {
    const { colDef, data } = params;
    const field = colDef.field;
    const rIndex = rowData.indexOf(data);
    if (rIndex === -1) return;

    const updated = rowData.map((row) => ({ ...row }));
    updated[rIndex][field] = data[field];

    const computed = computeAll(updated);
    setRowData(computed);

    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN && !broadcastingRef.current) {
      const msg = {
        type: "cell_edit",
        row: rIndex,
        col: field,
        value: data[field],
      };
      wsRef.current.send(JSON.stringify(msg));
    }
  };

  const importExcel = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      const data = new Uint8Array(evt.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const json = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });
      const maxCols = Math.max(...json.map((r) => r.length));
      const rows = json.map((r) => {
        const obj = {};
        for (let c = 0; c < maxCols; c++) obj[colsFromNumber(c + 1)] = r[c] ?? "";
        return obj;
      });
      setRowData(rows);
      const defs = [];
      for (let c = 0; c < maxCols; c++) defs.push({ field: colsFromNumber(c + 1), editable: true });
      setColumnDefs(defs);
    };
    reader.readAsArrayBuffer(file);
  };

  const exportExcel = () => {
    const headers = Object.keys(rowData[0] || {});
    const aoa = [headers];
    for (const r of rowData) {
      aoa.push(headers.map((h) => r[h]));
    }
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
    XLSX.writeFile(wb, "sheet-export.xlsx");
  };

  useEffect(() => {
    try {
      const WS_URL = (typeof window !== 'undefined' && process.env.NEXT_PUBLIC_WS_URL) ? process.env.NEXT_PUBLIC_WS_URL : 'ws://localhost:3001';
      const ws = new WebSocket(WS_URL);
      wsRef.current = ws;
      ws.onopen = () => console.log("WS connected");
      ws.onmessage = (evt) => {
        try {
          const msg = JSON.parse(evt.data);
          if (msg.type === "cell_edit") {
            broadcastingRef.current = true;
            setRowData((prev) => {
              const copy = prev.map((r) => ({ ...r }));
              if (!copy[msg.row]) return copy;
              copy[msg.row][msg.col] = msg.value;
              return computeAll(copy);
            });
            setTimeout(() => (broadcastingRef.current = false), 50);
          }
        } catch (e) {
          console.warn("ws parse err", e);
        }
      };
      ws.onclose = () => console.log("WS closed");
      ws.onerror = (e) => console.log("WS error", e);
      return () => ws.close();
    } catch (e) {
      console.warn("WS init failed", e);
    }
  }, []);

  const addRow = () => {
    const newRow = {};
    const cols = columnDefs.length ? columnDefs.map((d) => d.field) : Object.keys(rowData[0] || {});
    for (const c of cols) newRow[c] = "";
    setRowData((p) => [...p, newRow]);
  };

  return (
    <div style={{ padding: 12 }}>
      <h2>SheetHub - Excel-like Sheet (MVP)</h2>
      <div style={{ marginBottom: 8 }}>
        <button onClick={exportExcel} style={{ marginRight: 8 }}>تصدير Excel</button>
        <input type="file" accept=".xlsx,.xls,.csv" onChange={importExcel} style={{ marginRight: 8 }} />
        <button onClick={addRow} style={{ marginRight: 8 }}>إضافة صف</button>
      </div>
      <div className="ag-theme-alpine" style={{ height: 600, width: "100%" }}>
        <AgGridReact
          ref={gridRef}
          rowData={rowData}
          columnDefs={columnDefs}
          onCellValueChanged={onCellValueChanged}
          defaultColDef={{ flex: 1, minWidth: 80 }}
        />
      </div>
      <p style={{ marginTop: 10 }}>
        ملاحظة: الصيغ البسيطة تبدأ بعلامة "=" مثل <code>=A1+B1</code>. الصيغ المعقدة أو الدوال غير مدعومة في هذه النسخة الأولى.
      </p>
      <p>
        WebSocket: يحاول الاتصال بـ <code>ws://localhost:3001</code> لبث التغييرات لمستخدمين آخرين. لو لم تشغّل backend فلن يؤثر.
      </p>
    </div>
  );
}
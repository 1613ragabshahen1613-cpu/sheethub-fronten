const express = require('express');
const cors = require('cors');
const { WebSocketServer } = require('ws');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: 'SheetHub Backend running' });
});

const server = app.listen(process.env.PORT || 3001, () => console.log('Backend listening'));
const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
  console.log('WS connected');
  ws.on('message', (msg) => {
    // broadcast to others
    wss.clients.forEach((client) => {
      if (client !== ws && client.readyState === 1) client.send(msg.toString());
    });
  });
  ws.on('close', () => console.log('WS closed'));
});